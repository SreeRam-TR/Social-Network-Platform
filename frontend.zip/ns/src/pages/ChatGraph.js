import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { Text } from 'troika-three-text'; // For 3D text rendering

const ChatGraph = ({ users = [] }) => {
  const animationRef = useRef(); // Store the animation reference
  const isMouseOver = useRef(false); // Track if the mouse is over the canvas

  useEffect(() => {
    const width = 800;
    const height = 600;

    // Remove any existing canvases before creating a new one
    const existingCanvas = document.getElementById('three-canvas');
    if (existingCanvas) {
      existingCanvas.remove(); // Remove previous canvas if it exists
    }

    // Set up the scene
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();
    renderer.setSize(width, height);
    renderer.domElement.id = 'three-canvas'; // Assign an ID to the canvas
    document.getElementById('chat-graph').appendChild(renderer.domElement);

    // Create OrbitControls for user interaction
    const controls = new OrbitControls(camera, renderer.domElement);
    camera.position.z = 2;

    // Ensure users is an array before mapping
    const nodes = Array.isArray(users) ? users.map(user => ({ id: user.id, name: user.name, friends: user.friends })) : [];
    const links = [];

    nodes.forEach(node => {
      node.friends.forEach(friendId => {
        links.push({ source: node.id, target: friendId });
      });
    });

    // Create spheres and text for each node
    const nodeSpheres = {};
    const firstNodeId = nodes[0]?.id; // Get the ID of the first node

    nodes.forEach((node) => {
      const geometry = new THREE.SphereGeometry(0.05, 32, 32);
      let color;

      if (node.id === firstNodeId) {
        color = 0x00ff00; // Green for the first node
      } else if (node.friends.includes(firstNodeId)) {
        color = 0xffa500; // Orange for adjacent nodes
      } else {
        color = 0xff0000; // Red for all other nodes
      }

      const material = new THREE.MeshBasicMaterial({ color });
      const sphere = new THREE.Mesh(geometry, material);
      sphere.position.set(Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1);
      scene.add(sphere);
      nodeSpheres[node.id] = sphere;

      // Create text for the user's name
      const textMesh = new Text();
      textMesh.text = node.name;
      textMesh.fontSize = 0.1; // Set a base font size
      textMesh.color = 0xffffff;
      textMesh.anchorX = 'center';
      textMesh.anchorY = 'middle';
      textMesh.position.y = 0.15; // Position above the sphere

      // Add click event for alerting the username
      textMesh.addEventListener('click', () => {
        alert(`Username: ${node.name}`);
      });

      // Enable user interaction on text mesh
      textMesh.cursor = 'pointer';
      textMesh.sync();

      // Add the textMesh as a child of the sphere, so it moves and rotates with it
      sphere.add(textMesh);
    });

    // Create links
    const linkMaterial = new THREE.LineBasicMaterial({ color: 0x999999 });
    links.forEach(link => {
      const geometry = new THREE.BufferGeometry();
      const positions = new Float32Array(2 * 3); // Two vertices (x, y, z)
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const line = new THREE.Line(geometry, linkMaterial);
      scene.add(line);

      // Update the positions in the render loop
      link.line = line;
      link.source = nodeSpheres[link.source];
      link.target = nodeSpheres[link.target];
    });

    // Function to update the rotation of the scene
    const animate = () => {
      // Rotate the scene when the mouse is not over the canvas
      if (!isMouseOver.current) {
        scene.rotation.y += 0.001; // Slow rotation on the Y-axis
      }

      // Rotate the spheres
      nodes.forEach(node => {
        const sphere = nodeSpheres[node.id];
        sphere.rotation.y += 0.01; // Rotate the sphere around the Y-axis
      });

      // Update line positions
      links.forEach(link => {
        const positions = link.line.geometry.attributes.position.array;
        positions[0] = link.source.position.x;
        positions[1] = link.source.position.y;
        positions[2] = link.source.position.z;
        positions[3] = link.target.position.x;
        positions[4] = link.target.position.y;
        positions[5] = link.target.position.z;
        link.line.geometry.attributes.position.needsUpdate = true;
      });

      // Render the scene
      controls.update();
      renderer.render(scene, camera);

      // Request the next animation frame
      animationRef.current = requestAnimationFrame(animate);
    };

    animate(); // Start the animation

    // Event listeners to detect mouse over and leave
    const handleMouseEnter = () => { isMouseOver.current = true; };
    const handleMouseLeave = () => { isMouseOver.current = false; };

    // Add event listeners for mouse enter and leave
    renderer.domElement.addEventListener('mouseenter', handleMouseEnter);
    renderer.domElement.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      // Clean up Three.js resources on unmount
      cancelAnimationFrame(animationRef.current); // Stop the animation loop
      renderer.dispose();
      scene.clear();
      renderer.domElement.removeEventListener('mouseenter', handleMouseEnter);
      renderer.domElement.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [users]);

  return <div id="chat-graph"></div>;
};

export default ChatGraph;
